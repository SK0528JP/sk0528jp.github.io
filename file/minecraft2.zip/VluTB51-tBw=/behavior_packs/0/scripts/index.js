import { Player, world } from '@minecraft/server';
import { command_shortcut_form } from './ui/command_shortcut';

world.afterEvents.itemUse.subscribe(async ev => {
    /**@type {Player} */
    const player = ev.source;
    const item = ev.itemStack;
    
    if(item.typeId == 'cve:cmdsc') {
        if(!player.isOp() && !player.hasTag('op')) {
            player.runCommandAsync('tellraw @s {"rawtext":[{"text":"opを持っていない人は使用できません。"}]}')
            return;
        }
        await command_shortcut_form(player)
    }
})