import { DynamicPropertiesDefinition, EntityTypes, Player, world } from '@minecraft/server';
import { splitStrByByte, getBytesFromString } from './byteString';

const dataSaveSetting = "dataSaveSetting";
const oneLength = 900;
const oneStorageSize = 950;
const TAG_MAX_LENGTH = 256;

/**
 * 
 * @param {Player} player 
 * @param {string} dataName 
 * @returns {string}
 */
export function getPlayerData(player, dataName) {
    const dataLengthList = JSON.parse(world.getDynamicProperty(dataSaveSetting));
    if(!dataLengthList[dataName]) return;
    let res = "";
    for(let i = 0; i < Math.ceil(dataLengthList[dataName] / oneLength); i++) {
        res += player.getDynamicProperty(dataName + i);
    }
    return JSON.parse(res);
}

/**
 * 返り値
 * 0: 成功
 * 1: 文字列オーバー
 * null: 何かしらで失敗
 * @param {Player} player 
 * @param {string} dataName 
 * @param {Object} data
 * @returns {number}
 */
export function setPlayerData(player, dataName, data) {
    const saveStr = JSON.stringify(data);
    const dataLengthList = JSON.parse(world.getDynamicProperty(dataSaveSetting));
    if(getBytesFromString(saveStr) > dataLengthList[dataName]) return 1;
    const saveArr = splitStrByByte(saveStr);
    for(let i = 0; i < saveArr.length; i++) {
        player.setDynamicProperty(dataName + i, saveArr[i]);
    }
}

/**
 * 
 * @param  {Array<{dataName: string, maxLength: number}>} dataRegisterList 
 */
export function registerPlayerData(...dataRegisterList) {
    world.afterEvents.worldInitialize.subscribe(ev => {
        ev.propertyRegistry.registerWorldDynamicProperties(new DynamicPropertiesDefinition().defineString(dataSaveSetting, 900));
        const savedData = JSON.parse(world.getDynamicProperty(dataSaveSetting) ?? "{}");

        for(const dataRegister of dataRegisterList) {
            const propDef = new DynamicPropertiesDefinition();
            for(let i = 0; i < Math.ceil(dataRegister.maxLength / oneLength); i++) {
                propDef.defineString(dataRegister.dataName + i, oneStorageSize);
            }
            ev.propertyRegistry.registerEntityTypeDynamicProperties(propDef, EntityTypes.get("minecraft:player"));
            savedData[dataRegister.dataName] = dataRegister.maxLength;
        }

        world.setDynamicProperty(dataSaveSetting, JSON.stringify(savedData));
    })
}

export function getDataMaxLength(dataName) {
    const dataLengthList = JSON.parse(world.getDynamicProperty(dataSaveSetting));
    return dataLengthList[dataName];
}