import { Player, world } from '@minecraft/server';
import { splitStrByByte, getBytesFromString } from './byteString';

const dataSaveSetting = "dataSaveSetting";
const TAG_MAX_LENGTH = 256;
const MAX_DIGIT = 4;

/**
 * 
 * @param {Player} player 
 * @param {string} dataName 
 * @returns {string}
 */
export function getPlayerData(player, dataName) {
    const oneLength = TAG_MAX_LENGTH - getBytesFromString(dataName) - 1 - MAX_DIGIT;
    const dataLengthList = JSON.parse(world.getDynamicProperty(dataSaveSetting));
    if(!dataLengthList[dataName]) return;
    const tags = player.getTags().filter(tag => isDataTag(tag, dataName));
    let res = "";
    for(let i = 0; i < Math.ceil(dataLengthList[dataName] / oneLength); i++) {
        const found = tags.find(tag => tag.startsWith(dataName + i + "_"));
        if(found) {
            res += found.match(new RegExp(`^${dataName + i}_(.*)$`))[1];
        } else {
            break;
        }
    }
    if(res == "") {
        return undefined;
    } else {
        return JSON.parse(res);
    }
}

/**
 * 返り値
 * 0: 成功
 * 1: 文字列オーバー
 * null: 何かしらで失敗
 * @param {Player} player 
 * @param {string} dataName 
 * @param {Object} data
 * @returns {number}
 */
export function setPlayerData(player, dataName, data) {
    const oneLength = TAG_MAX_LENGTH - getBytesFromString(dataName) - 1 - MAX_DIGIT;
    const saveStr = JSON.stringify(data);
    const dataLengthList = JSON.parse(world.getDynamicProperty(dataSaveSetting));
    if(getBytesFromString(saveStr) > dataLengthList[dataName]) return 1;
    const saveArr = splitStrByByte(saveStr, oneLength);
    resetPlayerData(player, dataName);
    for(let i = 0; i < saveArr.length; i++) {
        player.addTag(dataName + i + "_" + saveArr[i]);
    }
}

/**
 * 
 * @param {Player} player 
 * @param {string} dataName 
 */
export function resetPlayerData(player, dataName) {
    player.getTags().filter(tag => isDataTag(tag, dataName)).forEach(tag => player.removeTag(tag));
}

/**
 * 
 * @param  {Array<{dataName: string, maxLength: number}>} dataRegisterList 
 */
export function registerPlayerData(...dataRegisterList) {
    const savedData = JSON.parse(world.getDynamicProperty(dataSaveSetting) ?? "{}");

    for(const dataRegister of dataRegisterList) {
        savedData[dataRegister.dataName] = dataRegister.maxLength;
    }

    world.setDynamicProperty(dataSaveSetting, JSON.stringify(savedData));
}

/**
 * 
 * @param {string} dataName 
 * @returns 
 */
export function getDataMaxLength(dataName) {
    const dataLengthList = JSON.parse(world.getDynamicProperty(dataSaveSetting));
    return dataLengthList[dataName];
}

/**
 * 
 * @param {string} str 
 * @param {string} dataName 
 * @returns 
 */
export function isDataTag(str, dataName) {
    return new RegExp(`^${dataName}\\d+_`).test(str);
}