/**
 * 
 * @param {string} str 
 * @returns 
 */
export function getBytesFromString(str) {
    return encodeURIComponent(str).replace(/%../g,"x").length;
}

/**
 * 
 * @param {string} str 
 * @param {number} size 
 */
export function splitStrByByte(str, size) {
    let i = 0;
    let res = [];
    const length = getBytesFromString(str);
    while(i < length) {
        const tmp = substrByte(str, i, size);
        i += getBytesFromString(tmp);
        res.push(tmp);
    }
    return res;
}

/**
 * 
 * @param {string} src 
 * @param {number} start 
 * @param {number} size 
 * @returns 
 */
export function substrByte(src, start, size) {
    let result = ""
    let count1 = 0
    let count2 = 0

    for(let i = 0; i < src.length; i++) {
        const c = src.charAt(i)
        const char_size = getBytesFromString(c);

        if (count1 >= start) {
            count2 += char_size
            if(count2 <= size) {
                result += c
            } else {
                break
            }  
        }
        count1 += char_size
    }

    return result
}