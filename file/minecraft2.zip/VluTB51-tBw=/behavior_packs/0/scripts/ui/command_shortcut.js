import { Player } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui'
import { getPlayerData, setPlayerData, registerPlayerData, resetPlayerData } from './dataSaver';

const cmdsc = "cmdsc";

registerPlayerData({dataName: cmdsc, maxLength: 10000});

/**
 * 
 * @param {Player} player 
 * @returns 
 */
const shortcut_form = function (player) {
    return new Promise(async r => {
        const cmd_list = getPlayerData(player, cmdsc) ?? [];
        if(!cmd_list.length) {
            player.sendMessage("コマンドが設定されていません");
            r(undefined);
            return;
        }

        const form = new ActionFormData();
        form.title('ショートカット一覧');
        cmd_list.forEach(i => form.button(i.name));

        const result = await form.show(player);
        if(result.isCanceled) r(undefined);

        cmd_list[result.selection].command.forEach(i=>player.runCommandAsync(i));
        r(true);
    })
}
/*
cmd_list
[
    {
        "name": "クリエ",
        "command": [
            "gamemode c"
        ]
    },
    {
        "name": "サバイバル",
        "command": [
            "gamemode s"
        ]
    }
]
*/

/**
 * 
 * @param {Player} player 
 */
const choose_edit_form = function (player) {
    return new Promise(async r => {
        const cmd_list = getPlayerData(player, cmdsc) ?? [];

        const form = new ActionFormData();
        form.title('編集選択')
            .button('新規作成');
        cmd_list.forEach(i => form.button(i.name));
        
        const result = await form.show(player);
        if(result.isCanceled) r(undefined);
        
        if(result.selection == 0) {
            cmd_list.unshift({
                name: '新規ボタン',
                command: [
                    'say test'
                ]
            });
            setDataAndThrowError(player, cmdsc, cmd_list);
            r(await choose_edit_form(player));
        }
        if(result.selection >= 1) {
            r(await edit_form(player, result.selection-1));
        }
    })
}

/**
 * 
 * @param {Player} player 
 * @returns 
 */
const edit_form = function (player, num) {
    return new Promise(async r => {
        const cmd_list = getPlayerData(player, cmdsc);
        if(!cmd_list) r();

        const form = new ActionFormData();
        form.title('コマンド編集')
            .body(`表示名:\n${cmd_list[num].name}\n\nコマンド:\n${cmd_list[num].command.join('\n')}`)
            .button('コマンド変更')
            .button('削除');

        const result = await form.show(player);
        if(result.isCanceled) r(undefined);
        switch(result.selection) {
            case 0:
                cmd_list[num] = await edit_button_form(player, cmd_list[num].name, cmd_list[num].command);
                if(cmd_list[num]) {
                    setDataAndThrowError(player, cmdsc, cmd_list);
                    player.sendMessage(`コマンド名: ${cmd_list[num].name}\nコマンド:\n${cmd_list[num].command.join('\n').replace(/"/g,'\\\"')}\nで設定しました`)
                }
                break;
            case 1:
                cmd_list.splice(num, 1);
                player.sendMessage("ボタンを削除しました");
                setDataAndThrowError(player, cmdsc, cmd_list);
                break;
        }
    })
}

/**
 * 
 * @param {Player} player 
 * @param {string} name 
 * @param {Array<string>} command 
 */
const edit_button_form = function (player, name, command) {
    return new Promise(async r => {
        const form = new ModalFormData();
        form.title('コマンドボタン編集')
            .textField('表示名', 'text', name);
        command.forEach((i,index) => {
            form.textField(index==0?'コマンド':'', 'text', i);
        });
        form.toggle('コマンド追加');

        const result = await form.show(player);
        if(result.isCanceled) r(undefined);
        if(result.formValues[result.formValues.length-1]) {
            r(await edit_button_form(player, result.formValues[0], [...result.formValues.slice(1,result.formValues.length-1),'']));
        } else {
            r({
                name: result.formValues[0],
                command: result.formValues.slice(1,result.formValues.length-1)
            });
        }
    })
}

/**
 * 
 * @param {Player} player 
 * @returns 
 */
export const command_shortcut_form = function (player) {
    return new Promise(async r => {
        const form = new ActionFormData();
        form.title('コマンドショートカットメニュー')
            .button('ショートカットへ')
            .button('編集')
            .button('ショートカットをリセット');
        
        const result = await form.show(player);
        if(result.isCanceled) r(undefined);
    
        switch (result.selection) {
            case 0:
                r(await shortcut_form(player));
                break;
            case 1:
                r(await choose_edit_form(player));
                break;
            case 2:
                r(await reset_form(player));
                break;
        }
    });
};

/**
 * 
 * @param {Player} player 
 * @returns 
 */
const reset_form = function (player) {
    return new Promise(async r => {
        const form = new MessageFormData();
        form.title('リセット確認')
            .body('本当にリセットしますか？')
            .button1('いいえ')
            .button2('はい');
        const result = await form.show(player);
        if(result.selection == 1) {
            player.sendMessage("コマンドをリセットしました");
            r(resetPlayerData(player, cmdsc));
        }
    })
}

/**
 * 
 * @param {Player} player 
 * @param {string} dataName 
 * @param {any} data 
 */
function setDataAndThrowError(player, dataName, data) {
    if(setPlayerData(player, dataName, data) == 1) {
        player.sendMessage("コマンドデータの保存容量が足りなくなりました。この変更を適用するには他のボタンを削除して容量を空けてください。");
    }
}